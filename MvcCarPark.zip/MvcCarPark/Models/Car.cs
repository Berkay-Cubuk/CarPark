using System;
using System.ComponentModel.DataAnnotations;

namespace MvcCarPark.Models {
    public class Car {
        public int Id { get; set; }
        public string Label { get; set; }
        public DateTime StartTime { get; set; }
    }
}