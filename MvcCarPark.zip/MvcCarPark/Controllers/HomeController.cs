﻿using Microsoft.AspNetCore.Mvc;
using System.Text.Encodings.Web;

namespace MvcCarPark.Controllers {
    public class HomeController : Controller {

        int carCount = 0;

        string[,] cars = new string[5, 2];

        [HttpGet]
        public IActionResult Index() {
            ViewData["Cars"] = cars;
            ViewData["carCount"] = carCount;
            
            return View();
        }

        [HttpPost]
        public IActionResult Index(string label) {
            cars[carCount, 0] = label;
            cars[carCount, 1] = "04.03.2020-23:56";
            carCount += 1;
            return Content($"Araç plakası => {cars[0, 0]}");
        }
    }
}
