using Microsoft.EntityFrameworkCore;
using MvcCarPark.Models;

namespace MvcCarPark.Data {
    public class MvcCarParkContext : DbContext {
        public MvcCarParkContext (DbContextOptions<MvcCarParkContext> options) : base(options) {

        } 
        
        public DbSet<Car> Car { get; set; }
    }
}